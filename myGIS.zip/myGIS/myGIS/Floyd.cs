﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myGIS
{
    public class Floyd
    {
        /// <summary>
        /// 图类
        /// </summary>
        private Graph gra;
        public Graph Gra
        {
            get { return gra; }
            set { gra = value; }
        }
        /// <summary>
        /// 用来存储顶点到顶点之间最短路径的权重  
        /// </summary>
        private int[,] d;
        public int[,] D
        {
            get { return d; }
            set { d = value; }
        }
        /// <summary>
        /// p[1][5]表示1到5的最短路径上 1的后继，例如1到5最短路劲为1-2-4-5 那么p[1][5]==2  
        /// </summary>
        private int[,] p;
        public int[,] P
        {
            get { return p; }
            set { p = value; }
        }
        public Floyd()
        {
            this.gra = new Graph();
            d = gra.Arc;
            /*d = new int[gra.NumVex, gra.NumVex];
            for (int i = 0; i < gra.NumVex; i++)
            {
                for (int j = 0; j < gra.NumVex; j++)
                {
                    d[i,j] = gra.Arc[i,j];
                }
                
            }*/
            p = new int[gra.NumVex, gra.NumVex];
            initP();
            

        }

        /// <summary>
        /// 对d和p进行变化
        /// </summary>
        public void work()
        {
            for (int k = 0; k < gra.NumVex; k++)
            {
                for (int v = 0; v < gra.NumVex; v++)
                {
                    for (int w = 0; w < gra.NumVex; w++)
                    {
                        if (d[v, w] > d[v, k] + d[k, w])
                        {
                            d[v, w] = d[v, k] + d[k, w];
                            p[v, w] = p[v, k];// p[v][w]是v--w最短路径上 v的下一顶点  

                        }
                    }
                }
            }
        }
        /// <summary>
        /// 初始化最短路径矩阵
        /// </summary>
        private void initP()
        {
            for (int i = 0; i < gra.NumVex; i++)
            {
                for (int j = 0; j < gra.NumVex; j++)
                {
                    p[i, j] = j;
                }
            }
        }

       

        public List<int> getShortestpath(int start, int end)
        {
            StringBuilder path = new StringBuilder();
            List<int> Shortestpath = new List<int>();
            int index = start;
            path.Append(start + "→");
            Shortestpath.Add(start);
            while (index != end)
            {
                index = p[index, end];
                if (index != end)
                {
                    path.Append(index + " →");
                    Shortestpath.Add(index);
                }
                else
                {
                    path.Append(index);
                    Shortestpath.Add(index);
                }
            }
            Console.WriteLine("从" + (start) + "到" + (end) + "的最短路径为"
                + d[start, end] + "\n该路劲为：" + path.ToString());
            return Shortestpath;
        }
    }
}
