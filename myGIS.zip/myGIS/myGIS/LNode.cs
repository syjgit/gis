﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myGIS
{
    /// <summary>
    /// 链表节点
    /// </summary>
    class LNode
    {
        private City data;

        public City Data
        {
            get { return data; }
            set { data = value; }
        }
        private LNode next;

        public LNode Next
        {
            get { return next; }
            set { next = value; }
        }

    }
}
