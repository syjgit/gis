﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myGIS
{
    /// <summary>
    /// 地级市对象
    /// </summary>
    public class City
    {
        //c_id*c_NAME*c_CLASS*p_id
        private string cityID;

        public string CityID
        {
            get { return cityID; }
            set { cityID = value; }
        }
        private string cityName;

        public string CityName
        {
            get { return cityName; }
            set { cityName = value; }
        }
        private string cityCLASS;

        public string CityCLASS
        {
            get { return cityCLASS; }
            set { cityCLASS = value; }
        }
        private string pointID;

        public string PointID
        {
            get { return pointID; }
            set { pointID = value; }
        }

    }
}
