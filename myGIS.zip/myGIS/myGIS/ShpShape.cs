﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myGIS
{
    public class ShpPolyline_gon
    {
        public int ID;
        public int ShapeType;
        public double MER_XMin;
        public double MER_XMax;
        public double MER_YMin;
        public double MER_YMax;
        public List<List<PurePoint>> Lines;

        public ShpPolyline_gon()
        {
            ID = 0;
            ShapeType = 3;
            Lines = new List<List<PurePoint>>();
            MER_XMin = 0.0;
            MER_XMax = 0.0;
            MER_YMin = 0.0;
            MER_YMax = 0.0;
        }
    }
    public class PurePoint
    {
        public double X;
        public double Y;
        public PurePoint()
        {
            X = 0.0;
            Y = 0.0;
        }
    }

    public class ShpPoint
    {
        public int ID;
        public int ShapeType;
        public PurePoint Coord;
        public ShpPoint()
        {
            ID = 0;
            ShapeType = 1;
            Coord = new PurePoint();
        }
    }
}
