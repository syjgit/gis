﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace myGIS
{
    class DMS
    {
        public List<City> citys = new List<City>();
        public City test(string s)
        {
            string key = "name";
            List<City> ListCity = citys;
            int n = ListCity.Count;
            double a = n / 0.7;
            int m = (int)a;
            HashTable HT = new HashTable(m);
            HT.CreateHashTable(ListCity, key);
            //HT.PrintHashList();

            City city = HT.Search(s);
            if (city != null)
                Console.WriteLine(city.CityName + "\t" + city.CityID);
            else
                Console.WriteLine("该城市不存在！");
            return city;
        }
        public City test(int s)
        {
            string key = "ID";
            List<City> ListCity = citys;
            int n = ListCity.Count;
            double a = n / 0.7;
            int m = (int)a;
            HashTable HT = new HashTable(m);
            HT.CreateHashTable(ListCity, key);
            //HT.PrintHashList();

            City city = HT.Search(s);
            /*if (city != null)
                Console.WriteLine(city.CityName + "\t" + city.CityID);
            else
                Console.WriteLine("该城市不存在！");*/
            return city;
        }
    }
}
