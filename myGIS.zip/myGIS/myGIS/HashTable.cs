﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myGIS
{
    class HashTable
    {
        private const int defaultSize = 99999; //初始化定义散列表长度

        private LNode[] HT;//以数组形式表示散列表

        //m为散列表的大小，也称bucket大小
        int m;
        //构造函数，初始化散列表
        public HashTable(int m)
        {
            this.m = m;
            int i;
            HT = new LNode[m];
            for (i = 0; i < m; i++)
            {
                HT[i] = null;
            }
        }

        //析构函数，清除一个散列表
        ~HashTable()
        {
            int i;
            LNode p;
            int m = HT.Length;
            for (i = 0; i < m; i++)
            {
                p = HT[i];
                while (p != null)
                {
                    HT[i] = p.Next;
                    p = null;
                    p = HT[i];

                }
            }
            HT = null;
        }

        //求一个元素的散列地址
        public int HashAddress(string key, string type)
        {
            if (type == "ID")
            {
                int address;
                //byte[] buf = System.Text.Encoding.Default.GetBytes(key);
                //Array.Reverse(buf);
                //UInt64 s = System.BitConverter.ToUInt64(buf, 0);
                int s = Convert.ToInt16(key);
                address = (int)s % m;
                return address;
            }
            if (type == "name")
            {
                int address;
                byte[] buf = System.Text.Encoding.Default.GetBytes(key);
                Array.Reverse(buf);
                UInt16 s = System.BitConverter.ToUInt16(buf, 0);
                //int s = Convert.ToInt16(key);
                address = s % m;
                return address;

            }
            return 0;
        }

        //基于拉链法创建散列表,其中n代表关键码的个数
        public void CreateHashTable(List<City> ListCity, string type)
        {
            int i;
            int n = ListCity.Count;
            if (n > m)//如果填充因子>1,则散列表的性能一定会降低,此时，发出警示
            {
                Console.WriteLine("Load factor>1!");
            }
            if (type == "name")
            {
                for (i = 0; i < n; i++)
                {
                    Insert(ListCity[i], "name");
                }
            }
            if (type == "ID")
            {
                for (i = 0; i < n; i++)
                {
                    Insert(ListCity[i], "ID");
                }
            }

        }

        //向散列表中插入一个元素
        public void Insert(City item, string keytype)
        {
            if (keytype == "name")
            {
                //计算item的散列地址
                int d = HashAddress(item.CityName, "name");
                //为新元素分配存储结点
                LNode p = new LNode();
                //把新结点插入到散列表d列单链表的表头
                p.Data = item;
                p.Next = HT[d];
                HT[d] = p;
            }
            if (keytype == "ID")
            {
                //计算item的散列地址
                int d = HashAddress(item.CityID, "ID");
                //为新元素分配存储结点
                LNode p = new LNode();
                //把新结点插入到散列表d列单链表的表头
                p.Data = item;
                p.Next = HT[d];
                HT[d] = p;
            }
        }


        //从散列表中查找一个元素(按名字）
        public City Search(string name)
        {
            //计算item的散列地址
            int d = HashAddress(name, "name");
            LNode p = HT[d];
            //从该单链表中顺序查找匹配的元素，若查找成功则返回该元素，否则返回空值
            while (p != null)
            {
                if (p.Data.CityName == name)
                {
                    return p.Data;
                }
                else
                    p = p.Next;
            }
            return null;
        }
        //从散列表中查找一个元素(按编号）
        public City Search(int ss)
        {
            string s = ss.ToString();
            //计算item的散列地址
            int d = HashAddress(s, "ID");
            LNode p = HT[d];
            //从该单链表中顺序查找匹配的元素，若查找成功则返回该元素，否则返回空值
            while (p != null)
            {
                if (p.Data.CityID == s)
                {
                    return p.Data;
                }
                else
                    p = p.Next;
            }
            return null;
        }

        //从散列表中删除一个元素(按名字）
        public bool Delete(string name)
        {
            //计算item的散列地址
            int d = HashAddress(name, "name");
            //p指向对应单链表的表头指针
            LNode p = HT[d];
            //若单链表为空，则删除失败返回假
            if (p == null)
                return false;
            //若表头节点为被删除的节点，则删除它后返回真
            if (p.Data.CityName == name)
            {
                HT[d] = p.Next;
                p = null;
                return true;
            }
            //从第二个节点起查找被删除的元素，若查找成功则删除它并返回真
            LNode q = p.Next;
            while (q != null)
            {
                if (q.Data.CityName == name)
                {
                    p.Next = q.Next;
                    q = null;
                    return true;
                }
                else
                {
                    p = q;
                    q = q.Next;
                }
            }
            //没有可删除的元素，则返回假
            return false;
        }

        //从散列表中删除一个元素(按编号）
        public bool Delete(int iID)
        {
            string ID = iID.ToString();
            //计算item的散列地址
            int d = HashAddress(ID, "ID");
            //p指向对应单链表的表头指针
            LNode p = HT[d];
            //若单链表为空，则删除失败返回假
            if (p == null)
                return false;
            //若表头节点为被删除的节点，则删除它后返回真
            if (p.Data.CityID == ID)
            {
                HT[d] = p.Next;
                p = null;
                return true;
            }
            //从第二个节点起查找被删除的元素，若查找成功则删除它并返回真
            LNode q = p.Next;
            while (q != null)
            {
                if (q.Data.CityID == ID)
                {
                    p.Next = q.Next;
                    q = null;
                    return true;
                }
                else
                {
                    p = q;
                    q = q.Next;
                }
            }
            //没有可删除的元素，则返回假
            return false;
        }

        //显示输出散列表中的所有元素
        public void PrintHashList()
        {
            LNode p;
            int i;
            for (i = 0; i < m; i++)
            {
                Console.WriteLine("i=" + i);
                p = HT[i];
                while (p != null)
                {
                    Console.WriteLine(p.Data.CityName + "\t" + p.Data.PointID);
                    p = p.Next;
                }
            }
        }
    }
}
