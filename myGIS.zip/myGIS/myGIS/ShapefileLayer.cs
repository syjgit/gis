﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myGIS
{
    public class ShapefileLayer
    {
        public string Name;
        public int ShapeType;
        public double MER_XMin;
        public double MER_YMin;
        public double MER_XMax;
        public double MER_YMax;
        public List<ShpPoint> PointShapes;
        public List<ShpPolyline_gon> PolyShapes;
        public List<int> Selection;

        public ShapefileLayer()
        {
            ShapeType = -1;
            PointShapes = new List<ShpPoint>();
            PolyShapes = new List<ShpPolyline_gon>();
            Selection = new List<int>();
            MER_XMin = 0.0;
            MER_YMin = 0.0;
            MER_XMax = 0.0;
            MER_YMax = 0.0;
            //Name = "";
        }
    }
}
