﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace myGIS
{
    public partial class Form1 : Form
    {
        protected List<ShapefileLayer> ShpLayers;
        List<City> citys;
        List<Railway> railways;
        List<Province> provinces;
        protected ArcNodeTable NetworkTable;
        protected double PointScale;
        protected double Global_XMin;
        protected double Global_YMin;
        protected double Global_XMax;
        protected double Global_YMax;
        public int flag = 0;
        string filename ;
        public Form1()
        {
            InitializeComponent();
            ShpLayers = new List<ShapefileLayer>();
            NetworkTable = new ArcNodeTable();
            PointScale = 0.0;
            Global_XMin = 1.0;
            Global_YMin = 1.0;
            Global_XMax = 1.0;
            Global_YMax = 1.0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            filename = Application.StartupPath+"\\data";
            //Console.WriteLine(feilname);
        }

        /// <summary>
        /// 计算全局外包矩形范围
        /// </summary>
        /// <param name="XMin"></param>
        /// <param name="YMin"></param>
        /// <param name="XMax"></param>
        /// <param name="YMax"></param>
        /// <returns></returns>
        private bool GetGlobalMER(out double XMin, out double YMin, out double XMax, out double YMax)
        {
            XMin = Double.MaxValue;
            YMin = Double.MaxValue;
            XMax = Double.MinValue;
            YMax = Double.MinValue;
            if (ShpLayers.Count > 0)
            {
                foreach (ShapefileLayer layer in ShpLayers)
                {
                    if (layer.MER_XMin < XMin)
                        XMin = layer.MER_XMin;
                    if (layer.MER_YMin < YMin)
                        YMin = layer.MER_YMin;
                    if (layer.MER_XMax > XMax)
                        XMax = layer.MER_XMax;
                    if (layer.MER_YMax > YMax)
                        YMax = layer.MER_YMax;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// 空间文件读取
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        private ShapefileLayer LoadShpFile(string filename)
        {
            FileStream DataFile = new FileStream(filename, FileMode.Open);
            BinaryReader DataReader = new BinaryReader(DataFile);

            ShapefileLayer ShpLayer = null;


            if (System.Net.IPAddress.NetworkToHostOrder(DataReader.ReadInt32()) == 9994)
            {
                DataReader.ReadInt32();
                DataReader.ReadInt32();
                DataReader.ReadInt32();
                DataReader.ReadInt32();
                DataReader.ReadInt32();
                int filelength = System.Net.IPAddress.NetworkToHostOrder(DataReader.ReadInt32()) * 2;
                int fileversion = DataReader.ReadInt32();
                int shapetype = DataReader.ReadInt32();
                double xmin = DataReader.ReadDouble();
                double ymin = DataReader.ReadDouble();
                double xmax = DataReader.ReadDouble();
                double ymax = DataReader.ReadDouble();
                double zmin = DataReader.ReadDouble();
                double zmax = DataReader.ReadDouble();
                double mmin = DataReader.ReadDouble();
                double mmax = DataReader.ReadDouble();
                ShpLayer = new ShapefileLayer();
                ShpLayer.ShapeType = shapetype;
                ShpLayer.MER_XMin = xmin;
                ShpLayer.MER_XMax = xmax;
                ShpLayer.MER_YMin = ymin;
                ShpLayer.MER_YMax = ymax;
                filelength -= 100;
                int rec = 0;
                while (filelength > 0)
                {
                    switch (shapetype)
                    {
                        case 1: // point
                            ShpPoint p = new ShpPoint();
                            p.ID = System.Net.IPAddress.NetworkToHostOrder(DataReader.ReadInt32());
                            //Console.WriteLine(p.ID);
                            DataReader.ReadInt32();
                            p.ShapeType = DataReader.ReadInt32();
                            p.Coord.X = DataReader.ReadDouble();
                            p.Coord.Y = DataReader.ReadDouble();
                            ShpLayer.PointShapes.Add(p);
                            rec++;
                            filelength -= 28;
                            break;
                        case 3: // polyline
                        case 5: // polygon
                            // Console.WriteLine();
                            ShpPolyline_gon polyshape = new ShpPolyline_gon();
                            polyshape.ID = System.Net.IPAddress.NetworkToHostOrder(DataReader.ReadInt32());
                            //Console.WriteLine(polyshape.ID);
                            int reclength = System.Net.IPAddress.NetworkToHostOrder(DataReader.ReadInt32()) * 2;
                            polyshape.ShapeType = DataReader.ReadInt32();
                            polyshape.MER_XMin = DataReader.ReadDouble();
                            polyshape.MER_YMin = DataReader.ReadDouble();
                            polyshape.MER_XMax = DataReader.ReadDouble();
                            polyshape.MER_YMax = DataReader.ReadDouble();
                            int parts = DataReader.ReadInt32();
                            int points = DataReader.ReadInt32();
                            int[] partindex = new int[parts];
                            double[] pts = new double[points * 2];
                            reclength -= 44;
                            // Console.WriteLine(polyshape.ID);
                            while (reclength > 8)
                            {
                                for (int i = 0; i < parts; i++)
                                {
                                    partindex[i] = DataReader.ReadInt32();
                                }
                                reclength -= parts * 4;
                                for (int i = 0; i < points; i++)
                                {
                                    pts[i * 2] = DataReader.ReadDouble();
                                    pts[i * 2 + 1] = DataReader.ReadDouble();
                                }
                                reclength -= points * 16;
                            }
                            List<PurePoint> ps = new List<PurePoint>();
                            for (int i = 0; i < points; i++)
                            {
                                int j = 0;
                                if (i == partindex[j])
                                {
                                    j++;
                                    ps = new List<PurePoint>();
                                    polyshape.Lines.Add(ps);
                                }
                                PurePoint v = new PurePoint();
                                v.X = pts[i * 2];
                                v.Y = pts[i * 2 + 1];
                                //Console.WriteLine(" x:"+ v.X + " y:" + v.Y);
                                ps.Add(v);
                            }
                            ShpLayer.PolyShapes.Add(polyshape);
                            filelength -= 8 + 44 + parts * 4 + points * 16;
                            break;
                        default:
                            filelength = 0;
                            break;
                    }
                }
            }
            DataReader.Close();
            DataFile.Close();
            return ShpLayer;
        }


        /// <summary>
        /// 判断图层的元素是否被选中
        /// </summary>
        /// <param name="nID"></param>
        /// <param name="layer"></param>
        /// <returns></returns>
        private bool IsSelected(int nID, ShapefileLayer layer)
        {
            foreach (int id in layer.Selection)
            {
                if (id == nID)
                    return true;
            }
            return false;
        }
        /// <summary>
        /// 图层绘制详细方法
        /// </summary>
        /// <param name="g"></param>
        /// <param name="layer"></param>
        private void PaintShapeLayer(Graphics g, ShapefileLayer layer)
        {
            if (layer.ShapeType == -1)
                return;
            PointScale = pbField.Size.Height / 80;
            Pen PointPen = new Pen(Color.Black, 2);
            Pen SelectedPen = new Pen(Color.Blue, 4);
            Pen LinePen = new Pen(Color.DarkGray, 2);
            Pen GonPen = new Pen(Color.Brown, 2);
            SolidBrush RegionBrush = new SolidBrush(Color.Gray);
            double dFieldHeigth = Global_YMax - Global_YMin;
            double dFieldwidth = Global_XMax - Global_XMin;
            double dHeigthRatio = dFieldHeigth / pbField.Size.Height;
            double dWidthRatio = dFieldwidth / pbField.Size.Width;
            switch (layer.ShapeType)
            {
                case 1: // Point
                    foreach (ShpPoint p in layer.PointShapes)
                    {
                        double tx = (p.Coord.X - Global_XMin) / dWidthRatio;
                        double ty = (dFieldHeigth - p.Coord.Y + Global_YMin) / dHeigthRatio;
                        if (IsSelected(p.ID, layer))
                            g.DrawEllipse(SelectedPen, (float)(tx - PointScale), (float)(ty - PointScale), (float)(PointScale * 2), (float)(PointScale * 2));
                        else
                            g.FillEllipse(RegionBrush, (float)(tx - PointScale / 2), (float)(ty - PointScale / 2), (float)(PointScale), (float)(PointScale));
                    }
                    break;
                case 3: // Polyline
                    foreach (ShpPolyline_gon polyline in layer.PolyShapes)
                    {
                        foreach (List<PurePoint> line in polyline.Lines)
                        {

                            PointF[] points = new PointF[line.Count];
                            int i = 0;
                            foreach (PurePoint p in line)
                            {
                                float x = (float)((p.X - Global_XMin) / dWidthRatio);
                                float y = (float)((dFieldHeigth - p.Y + Global_YMin) / dHeigthRatio);
                                PointF vertex = new PointF(x, y);
                                points[i] = vertex;
                                i++;
                            }
                            if (IsSelected(polyline.ID, layer))
                                g.DrawLines(SelectedPen, points);
                            else
                                g.DrawLines(LinePen, points);

                        }
                    }
                    break;
                case 5: // Polygon
                    foreach (ShpPolyline_gon polygon in layer.PolyShapes)
                    {
                        foreach (List<PurePoint> line in polygon.Lines)
                        {
                            PointF[] points = new PointF[line.Count];
                            int i = 0;
                            foreach (PurePoint p in line)
                            {
                                float x = (float)((p.X - Global_XMin) / dWidthRatio);
                                float y = (float)((dFieldHeigth - p.Y + Global_YMin) / dHeigthRatio);
                                PointF vertex = new PointF(x, y);
                                points[i] = vertex;
                                i++;
                            }
                            if (IsSelected(polygon.ID, layer))
                                g.DrawLines(SelectedPen, points);
                            else
                                g.DrawLines(GonPen, points);
                            //g.FillPolygon(RegionBrush, points);
                        }
                    }
                    break;
                default:
                    break;
            }

        }
        /// <summary>
        /// 绘制图层
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbField_Paint(object sender, PaintEventArgs e)
        {
            for (int i = ShpLayers.Count - 1; i >= 0; i--)
            {
                if (ShpLayers[i].ShapeType != 5)
                {
                    PaintShapeLayer(e.Graphics, ShpLayers[i]);
                }
                else
                {
                    PaintShapeLayer(e.Graphics, ShpLayers[i]);
                }
            }

        }
        /// <summary>
        /// 更新左侧图层目录栏
        /// </summary>
        private void update_treeView()
        {
            treeView.Nodes.Clear();

            foreach (ShapefileLayer layer in ShpLayers)
            {
                TreeNode node = treeView.Nodes.Add(layer.Name);
            }
        }

        private void pbField_SizeChanged(object sender, EventArgs e)
        {
            pbField.Refresh();
        }
        /// <summary>
        /// 加载所有图层
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addlayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// 导入地级市点图层
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void add_CityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Attri_path = filename+ "\\地级市.sss";
            string spa_path = filename + "\\地级市.shp";
            if (File.Exists(spa_path)&&File.Exists(Attri_path))
            {
                citys = LoadCity(Attri_path);
                ShapefileLayer layer = LoadShpFile(spa_path);//导入点shp
                if (layer != null && layer.ShapeType == 1)
                {
                    layer.Name = System.IO.Path.GetFileNameWithoutExtension(spa_path);
                    layer.Selection.Clear();
                    ShpLayers.Add(layer);
                }
                GetGlobalMER(out Global_XMin, out Global_YMin, out Global_XMax, out Global_YMax);
                update_treeView();
                pbField.Refresh();
            }
            else
            {
                MessageBox.Show("城市文件错误");
            }
        }

        /// <summary>
        /// 导入city属性信息，在导入城市图层的方法中调用
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private List<City> LoadCity(string path)
        {
            List<City> ListCity = new List<City>();
            StreamReader str = new StreamReader(path, Encoding.Default);
            string line;
            while ((line = str.ReadLine()) != null)
            {
                string[] s = line.Split(new char[] { '*' });
                City city = new City();
                city.CityID = s[0];
                city.CityName = s[1];
                city.CityCLASS = s[2];
                city.PointID = s[3];
                ListCity.Add(city);
            }
            str.Close();
            return ListCity;
        }
        /// <summary>
        /// 导入省界面图层
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void add_PolygonToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string Attri_path = filename + "\\省份.sss";
            string spa_path = filename + "\\省份.shp";
            if (File.Exists(spa_path) && File.Exists(Attri_path))
            {
                provinces = Loadprovince(Attri_path);
                ShapefileLayer layer = LoadShpFile(spa_path);
                if (layer != null && layer.ShapeType == 5)
                {
                    layer.Name = System.IO.Path.GetFileNameWithoutExtension(spa_path);
                    layer.Selection.Clear();
                    ShapefileLayer oldlayer = NetworkTable.ArcLayer;
                    ShpLayers.Add(layer);
                }
                GetGlobalMER(out Global_XMin, out Global_YMin, out Global_XMax, out Global_YMax);
                update_treeView();
                pbField.Refresh();
            }
            else
            {
                MessageBox.Show("省份文件出错");
            }
        }

        /// <summary>
        /// 导入省份属性文件
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private List<Province> Loadprovince(string path)
        {
            List<Province> Listprovince = new List<Province>();
            StreamReader str = new StreamReader(path, Encoding.Default);
            string line;
            while ((line = str.ReadLine()) != null)
            {
                string[] s = line.Split(new char[] { '*' });
                Province pro = new Province();
                pro.P_ID = Convert.ToInt32(s[0]);
                pro.Area = Convert.ToDouble(s[1]);
                pro.P_name = s[2];
                Listprovince.Add(pro);
            }
            str.Close();
            return Listprovince;
        }

        /// <summary>
        /// 导入铁路线图层
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void add_PolylineToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string Attri_path = filename+ "\\铁路.sss";
            string spa_path = filename + "\\铁路.shp";
            if (File.Exists(spa_path)&&File.Exists(Attri_path))
            {
                add_Point();
                railways = LoadRailway(Attri_path);
                ShapefileLayer layer = LoadShpFile(spa_path);
                if (layer != null && layer.ShapeType == 3)
                {
                    layer.Name = System.IO.Path.GetFileNameWithoutExtension(spa_path);
                    layer.Selection.Clear();
                    ShapefileLayer oldlayer = NetworkTable.ArcLayer;
                    NetworkTable.ArcLayer = layer;
                    //setArcLength();
                    bool bReplaced = false;
                    if (oldlayer != null)
                    {
                        for (int i = 0; i < ShpLayers.Count; i++)
                        {
                            if (ShpLayers[i] == oldlayer)
                            {
                                ShpLayers[i] = layer;
                                bReplaced = true;
                                break;
                            }
                        }
                    }
                    if (!bReplaced)
                    {
                        ShpLayers.Add(layer);
                    }
                }
                GetGlobalMER(out Global_XMin, out Global_YMin, out Global_XMax, out Global_YMax);
                update_treeView();
                pbField.Refresh();
            }
            else
            {
                MessageBox.Show("城市文件错误");
            }
        }

        /// <summary>
        /// 导入铁路属性信息
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private List<Railway> LoadRailway(string path)
        {
            List<Railway> ListRai = new List<Railway>();
            StreamReader str = new StreamReader(path, Encoding.Default);
            string line;
            while ((line = str.ReadLine()) != null)
            {
                string[] s = line.Split(new char[] { '*' });
                Railway rai = new Railway();
                rai.R_ID =Convert.ToInt32(s[0]);
                rai.Length =Convert.ToDouble(s[1]);
                rai.Name = s[2];
                ListRai.Add(rai);
            }
            str.Close();
            return ListRai;
        }

        /// <summary>
        /// 导入铁路节点图层，在导入铁路图层中调用
        /// </summary>
        private void add_Point()
        {
            string spa_path = filename + "\\铁路_ND.shp";
            if (File.Exists(spa_path))
            {
                ShapefileLayer layer = LoadShpFile(spa_path);//导入点shp
                if (layer != null && layer.ShapeType == 1)
                {
                    layer.Name = System.IO.Path.GetFileNameWithoutExtension(spa_path);
                    NetworkTable.NodeLayer = layer;
                }
                GetGlobalMER(out Global_XMin, out Global_YMin, out Global_XMax, out Global_YMax);
                pbField.Refresh();
            }
            else
            {
                MessageBox.Show("缺少节点信息");
            }
        }

        /// <summary>
        /// 鼠标移动事件 对象捕捉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbField_MouseMove(object sender, MouseEventArgs e)//
        {
            if (ShpLayers.Count != 0)
            {
                string o = Convert.ToInt32(ToMapPoint(e.Location).Coord.X) + "," + Convert.ToInt32(ToMapPoint(e.Location).Coord.Y);//右下角显示坐标
                label1.Text = o;
                foreach (ShapefileLayer layer in ShpLayers)
                {
                    if (layer.Name=="地级市")
                    {
                        bool bSelectionChanged = false;
                        
                        if (layer.Selection.Count > 0)
                        {
                            layer.Selection.Clear();
                            bSelectionChanged = true;
                        }

                        double dFieldHeigth = Global_YMax - Global_YMin;
                        double dFieldwidth = Global_XMax - Global_XMin;
                        double dHeigthRatio = dFieldHeigth / pbField.Size.Height;
                        double dWidthRatio = dFieldwidth / pbField.Size.Width;

                        foreach (ShpPoint p in layer.PointShapes)
                        {
                            double tx = (p.Coord.X - Global_XMin) / dWidthRatio;
                            double ty = (dFieldHeigth - p.Coord.Y + Global_YMin) / dHeigthRatio;
                            if (Math.Abs(e.X - tx) < PointScale && Math.Abs(e.Y - ty) < PointScale)
                            {
                                //NetworkTable.NodeLayer.Selection.Add(p.ID);
                                layer.Selection.Add(p.ID);
                                City q = selectCity(p.ID);
                                label2.Text = q.CityName;//左下角显示城市名称
                                bSelectionChanged = true;

                                break;
                            }
                        }
                        if (bSelectionChanged)
                        {
                            pbField.Refresh();
                        }
                    }

                }

            }
        }

        /// <summary>
        /// 生成arcnodetable
        /// </summary>
        /// <param name="nodelayer"></param>
        /// <param name="arclayer"></param>
        /// <returns></returns>
        private List<ArcNodeItem> NonDirectionArcNodeTable(ShapefileLayer nodelayer, ShapefileLayer arclayer)
        {
            List<ArcNodeItem> Items = new List<ArcNodeItem>();
            foreach (ShpPolyline_gon Polyline in arclayer.PolyShapes)
            {
                ArcNodeItem Item = new ArcNodeItem();
                Item.Arc = Polyline.ID;
                foreach (Railway rai in railways)
                {
                    if (Polyline.ID == rai.R_ID)
                    {
                        Item.length =Convert.ToInt32(rai.Length);
                    }
                }
                foreach (List<PurePoint> arc in Polyline.Lines)
                {
                    int i = 0;
                    foreach (PurePoint arcPoint in arc)
                    {
                        foreach (ShpPoint nodePoint in nodelayer.PointShapes)
                        {
                            if (i == 0)
                            {
                                if (nodePoint.Coord.X == arcPoint.X && nodePoint.Coord.Y == arcPoint.Y)
                                {
                                    Item.FromNode = nodePoint.ID;
                                    i++;
                                }
                            }
                            else
                            {
                                if (nodePoint.Coord.X == arcPoint.X && nodePoint.Coord.Y == arcPoint.Y)
                                {
                                    Item.ToNode = nodePoint.ID;
                                }
                            }
                        }
                    }
                }
                Items.Add(Item);
            }
            return Items;
        }

        public void creatTable()//生成arcnodetable
        {
            try
            {
                List<ArcNodeItem> items = NonDirectionArcNodeTable(NetworkTable.NodeLayer, NetworkTable.ArcLayer);
                if (items != null)
                {
                    NetworkTable.ArcNodeItems = items;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("生成网络失败");
            }
        }

        private void 最短路径ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int startNode, endNode;
            try
            {
                creatTable();
                startNode = selectNode(Convert.ToInt32(selectCity(textBox1.Text.ToString()).CityID));
                endNode = selectNode(Convert.ToInt32(selectCity(textBox2.Text.ToString()).CityID));
                // startNode = Convert.ToInt32(textBox1.Text);
                MessageBox.Show(startNode + "," + endNode);

                if (startNode != -1 && endNode != -1)
                {
                    if (NetworkTable.ArcLayer != null && NetworkTable.ArcLayer.Selection.Count > 0)
                    {
                        NetworkTable.ArcLayer.Selection.Clear();
                    }
                    if (NetworkTable.NodeLayer.Selection.Count > 0)
                    {
                        NetworkTable.NodeLayer.Selection.Clear();

                    }

                    Floyd floyd = new Floyd();
                    tabletoArc(floyd.Gra);
                    floyd.work();
                    List<int> path = floyd.getShortestpath(startNode - 1, endNode - 1);
                    //加最大判断
                    addShortestpath(path);
                    pbField.Refresh();
                }
                else
                {
                    MessageBox.Show("未找到最近节点");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误!!请检查图层和城市名");
            }

        }
        /// <summary>
        /// 计算与城市最临近的节点
        /// </summary>
        /// <param name="city"></param>
        /// <returns></returns>
        private int selectNode(int city)
        {
            int select = -1;
            double s = 5;
            double s1;
            foreach (ShapefileLayer layer in ShpLayers)
            {
                if (layer.Name == "地级市")
                {
                    foreach (ShpPoint p in layer.PointShapes)
                    {
                        if (p.ID == city)
                        {
                            //Console.WriteLine(p.Coord.X + "，" + p.Coord.Y);
                            foreach (ShpPoint nodePoint in NetworkTable.NodeLayer.PointShapes)
                            {
                                s1 = (p.Coord.X - nodePoint.Coord.X) * (p.Coord.X - nodePoint.Coord.X) + (p.Coord.Y - nodePoint.Coord.Y) * (p.Coord.Y - nodePoint.Coord.Y);
                                if (s1 < s)
                                {
                                    //Console.WriteLine(nodePoint.Coord.X + "，" + nodePoint.Coord.Y+","+nodePoint.ID);
                                    s = s1;
                                    select = nodePoint.ID;
                                }
                            }
                        }

                    }
                }
            }
            return select;
        }

        private void tabletoArc(Graph graph)//将arcnodetable转成arc
        {
            List<ArcNodeItem> items = NetworkTable.ArcNodeItems;
            foreach (ArcNodeItem item in items)
            {
                int i = item.FromNode - 1;
                int j = item.ToNode - 1;
                graph.Arc[i, j] = item.length;
                graph.Arc[j, i] = item.length;
            }
        }

        /// <summary>
        /// 将最短路径的道路高亮
        /// </summary>
        /// <param name="path"></param>
        private void addShortestpath(List<int> path)
        {
            for (int i = 0; i < path.Count - 1; i++)
            {
                foreach (ArcNodeItem item in NetworkTable.ArcNodeItems)
                {
                    if (item.FromNode == path[i] + 1 && item.ToNode == path[i + 1] + 1)
                    {
                        NetworkTable.ArcLayer.Selection.Add(item.Arc);
                    }
                    else if (item.ToNode == path[i] + 1 && item.FromNode == path[i + 1] + 1)
                    {
                        NetworkTable.ArcLayer.Selection.Add(item.Arc);
                    }
                }
            }

        }

        private void 点ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flag = 1;
        }

        private void 线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flag = 3;
        }

        private void 面ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flag = 5;
        }

        private void pbField_MouseDown(object sender, MouseEventArgs e)
        {
            if (flag != 0)
            {
                if (e.Clicks == 1)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        ShpPoint temp = ToMapPoint(e.Location);
                    }
                }
            }
            else
            {
                update_dataGridView();
            }
        }

        private void update_dataGridView()
        {
            //设置dataGridView
        }

        /// <summary>
        /// 将图中点转成实际点，界面右下角坐标点的显示
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        private ShpPoint ToMapPoint(Point point)
        {
            ShpPoint p = new ShpPoint();
            double dFieldHeigth = Global_YMax - Global_YMin;
            double dFieldwidth = Global_XMax - Global_XMin;
            double dHeigthRatio = dFieldHeigth / pbField.Size.Height;
            double dWidthRatio = dFieldwidth / pbField.Size.Width;

            p.Coord.X = point.X * dWidthRatio + Global_XMin;
            p.Coord.Y = Global_YMin + dFieldHeigth - point.Y * dHeigthRatio;
            return p;
        }


        /// <summary>
        /// 按名字查询城市，然后高亮，在左下角datagridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 按名字ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (ShapefileLayer layer in ShpLayers)
                {
                    if (layer.PointShapes != null)
                    {
                        City city =selectCity(textBox1.Text.ToString());
                        layer.Selection.Add(Convert.ToInt32(city.CityID));
                        label2.Text = city.CityName;
                        showcityIndataGridView(city);
                        pbField.Refresh();
                    }
                }
                //

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void showcityIndataGridView(City city)
        {
           
        }

        /// <summary>
        /// 通过哈希表按名字查询城市
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public City selectCity(string s)
        {
            DMS select = new DMS();
            select.citys = citys;
            City city = select.test(s);
            return city;
        }
        /// <summary>
        /// 通过哈希表按编号查询城市
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public City selectCity(int s)
        {
            DMS select = new DMS();
            select.citys = citys;
            City city = select.test(s);
            return city;
        }

    }
}
