﻿namespace myGIS
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.菜单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addlayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.加载ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.add_PolylineToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.add_CityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.add_PolygonToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.绘制ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.点ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.面ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.完成ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.网络ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.最短路径ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选择ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.按名字ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.按省份ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView = new System.Windows.Forms.TreeView();
            this.label1 = new System.Windows.Forms.Label();
            this.pbField = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbField)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单ToolStripMenuItem,
            this.加载ToolStripMenuItem,
            this.绘制ToolStripMenuItem,
            this.网络ToolStripMenuItem,
            this.选择ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(713, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 菜单ToolStripMenuItem
            // 
            this.菜单ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addlayerToolStripMenuItem});
            this.菜单ToolStripMenuItem.Name = "菜单ToolStripMenuItem";
            this.菜单ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.菜单ToolStripMenuItem.Text = "菜单";
            // 
            // addlayerToolStripMenuItem
            // 
            this.addlayerToolStripMenuItem.Name = "addlayerToolStripMenuItem";
            this.addlayerToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.addlayerToolStripMenuItem.Text = "加载所有图层";
            this.addlayerToolStripMenuItem.Click += new System.EventHandler(this.addlayerToolStripMenuItem_Click);
            // 
            // 加载ToolStripMenuItem
            // 
            this.加载ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.add_PolylineToolStripMenuItem1,
            this.add_CityToolStripMenuItem,
            this.add_PolygonToolStripMenuItem1});
            this.加载ToolStripMenuItem.Name = "加载ToolStripMenuItem";
            this.加载ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.加载ToolStripMenuItem.Text = "加载";
            // 
            // add_PolylineToolStripMenuItem1
            // 
            this.add_PolylineToolStripMenuItem1.Name = "add_PolylineToolStripMenuItem1";
            this.add_PolylineToolStripMenuItem1.Size = new System.Drawing.Size(138, 24);
            this.add_PolylineToolStripMenuItem1.Text = "铁路线";
            this.add_PolylineToolStripMenuItem1.Click += new System.EventHandler(this.add_PolylineToolStripMenuItem1_Click);
            // 
            // add_CityToolStripMenuItem
            // 
            this.add_CityToolStripMenuItem.Name = "add_CityToolStripMenuItem";
            this.add_CityToolStripMenuItem.Size = new System.Drawing.Size(138, 24);
            this.add_CityToolStripMenuItem.Text = "地级市";
            this.add_CityToolStripMenuItem.Click += new System.EventHandler(this.add_CityToolStripMenuItem_Click);
            // 
            // add_PolygonToolStripMenuItem1
            // 
            this.add_PolygonToolStripMenuItem1.Name = "add_PolygonToolStripMenuItem1";
            this.add_PolygonToolStripMenuItem1.Size = new System.Drawing.Size(138, 24);
            this.add_PolygonToolStripMenuItem1.Text = "省界";
            this.add_PolygonToolStripMenuItem1.Click += new System.EventHandler(this.add_PolygonToolStripMenuItem1_Click);
            // 
            // 绘制ToolStripMenuItem
            // 
            this.绘制ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.点ToolStripMenuItem,
            this.线ToolStripMenuItem,
            this.面ToolStripMenuItem,
            this.完成ToolStripMenuItem});
            this.绘制ToolStripMenuItem.Name = "绘制ToolStripMenuItem";
            this.绘制ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.绘制ToolStripMenuItem.Text = "绘制";
            // 
            // 点ToolStripMenuItem
            // 
            this.点ToolStripMenuItem.Name = "点ToolStripMenuItem";
            this.点ToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.点ToolStripMenuItem.Text = "点";
            this.点ToolStripMenuItem.Click += new System.EventHandler(this.点ToolStripMenuItem_Click);
            // 
            // 线ToolStripMenuItem
            // 
            this.线ToolStripMenuItem.Name = "线ToolStripMenuItem";
            this.线ToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.线ToolStripMenuItem.Text = "线";
            this.线ToolStripMenuItem.Click += new System.EventHandler(this.线ToolStripMenuItem_Click);
            // 
            // 面ToolStripMenuItem
            // 
            this.面ToolStripMenuItem.Name = "面ToolStripMenuItem";
            this.面ToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.面ToolStripMenuItem.Text = "面";
            this.面ToolStripMenuItem.Click += new System.EventHandler(this.面ToolStripMenuItem_Click);
            // 
            // 完成ToolStripMenuItem
            // 
            this.完成ToolStripMenuItem.Name = "完成ToolStripMenuItem";
            this.完成ToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.完成ToolStripMenuItem.Text = "完成";
            // 
            // 网络ToolStripMenuItem
            // 
            this.网络ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.最短路径ToolStripMenuItem});
            this.网络ToolStripMenuItem.Name = "网络ToolStripMenuItem";
            this.网络ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.网络ToolStripMenuItem.Text = "网络";
            // 
            // 最短路径ToolStripMenuItem
            // 
            this.最短路径ToolStripMenuItem.Name = "最短路径ToolStripMenuItem";
            this.最短路径ToolStripMenuItem.Size = new System.Drawing.Size(138, 24);
            this.最短路径ToolStripMenuItem.Text = "最短路径";
            this.最短路径ToolStripMenuItem.Click += new System.EventHandler(this.最短路径ToolStripMenuItem_Click);
            // 
            // 选择ToolStripMenuItem
            // 
            this.选择ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.按名字ToolStripMenuItem,
            this.按省份ToolStripMenuItem});
            this.选择ToolStripMenuItem.Name = "选择ToolStripMenuItem";
            this.选择ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.选择ToolStripMenuItem.Text = "选择";
            // 
            // 按名字ToolStripMenuItem
            // 
            this.按名字ToolStripMenuItem.Name = "按名字ToolStripMenuItem";
            this.按名字ToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
            this.按名字ToolStripMenuItem.Text = "按名字";
            this.按名字ToolStripMenuItem.Click += new System.EventHandler(this.按名字ToolStripMenuItem_Click);
            // 
            // 按省份ToolStripMenuItem
            // 
            this.按省份ToolStripMenuItem.Name = "按省份ToolStripMenuItem";
            this.按省份ToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
            this.按省份ToolStripMenuItem.Text = "按省份";
            // 
            // treeView
            // 
            this.treeView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.treeView.Location = new System.Drawing.Point(12, 41);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(100, 201);
            this.treeView.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(661, 544);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "0,0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbField
            // 
            this.pbField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbField.BackColor = System.Drawing.SystemColors.Window;
            this.pbField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField.Location = new System.Drawing.Point(118, 41);
            this.pbField.Name = "pbField";
            this.pbField.Size = new System.Drawing.Size(595, 492);
            this.pbField.TabIndex = 5;
            this.pbField.TabStop = false;
            this.pbField.SizeChanged += new System.EventHandler(this.pbField_SizeChanged);
            this.pbField.Paint += new System.Windows.Forms.PaintEventHandler(this.pbField_Paint);
            this.pbField.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbField_MouseDown);
            this.pbField.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbField_MouseMove);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(332, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(453, 0);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 25);
            this.textBox2.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 544);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "         0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 248);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(100, 285);
            this.dataGridView1.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 568);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pbField);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.treeView);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbField)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 绘制ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 点ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 线ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 面ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addlayerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 加载ToolStripMenuItem;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem add_PolylineToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem add_PolygonToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pbField;
        private System.Windows.Forms.ToolStripMenuItem 网络ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ToolStripMenuItem 最短路径ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 完成ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 选择ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 按名字ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 按省份ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem add_CityToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

