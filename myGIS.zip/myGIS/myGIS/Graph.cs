﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace myGIS
{
    public class Graph
    {
        private int numVex = 164;

        public int NumVex
        {
            get { return numVex; }
            set { numVex = value; }
        }
        private int[,] arc = null;

        public int[,] Arc
        {
            get { return arc; }
            set { arc = value; }
        }
        private int numEdge = 189;

        public int NumEdge
        {
            get { return numEdge; }
            set { numEdge = value; }
        }
        private int INFINITY = 99999;

        public int INFINITY1
        {
            get { return INFINITY; }
            set { INFINITY = value; }
        }

        public Graph()
        {
            arc = new int[NumVex, NumVex];
            for (int i = 0; i < numVex; i++)
            {
                for (int j = 0; j < numVex; j++)
                {
                    arc[i, j] = INFINITY;
                }
            }
            for (int i = 0; i < numVex; i++)
                arc[i, i] = 0;


        }

        
    }
}
