﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myGIS
{
    public class Railway
    {
        private int r_ID;
        /// <summary>
        /// 铁路段编号
        /// </summary>
        public int R_ID
        {
            get { return r_ID; }
            set { r_ID = value; }
        }
        private double length;
        /// <summary>
        /// 铁路段长度
        /// </summary>
        public double Length
        {
            get { return length; }
            set { length = value; }
        }
        private string name;
        /// <summary>
        /// 铁路段名称
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
