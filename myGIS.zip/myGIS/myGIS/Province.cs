﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myGIS
{
    /// <summary>
    /// 省份
    /// </summary>
    public class Province
    {
        private int p_ID;
        /// <summary>
        /// 省份id
        /// </summary>
        public int P_ID
        {
            get { return p_ID; }
            set { p_ID = value; }
        }
        private double area;
        /// <summary>
        /// 省份面积
        /// </summary>
        public double Area
        {
            get { return area; }
            set { area = value; }
        }
        private string p_name;
        /// <summary>
        /// 省份名称
        /// </summary>
        public string P_name
        {
            get { return p_name; }
            set { p_name = value; }
        }
    }
}
